/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author sairammantravadi
 */
public class ServiceHistory {
    
    private ArrayList<product> history;
    
    public ServiceHistory(){
    this.history = new ArrayList<product>();
    }

    
    public product AddNewProduct(){
        
        product NewProduct = new product();
        history.add(NewProduct);
        return NewProduct;
}
    
    
    
    
    
    
    
    
    
    public ArrayList<product> getHistory() {
        return history;
    }

    public void setHistory(ArrayList<product> history) {
        this.history = history;
    }

    public void deleteproduct(product selectedProducts) {
        
        history.remove(selectedProducts);
        
    }
    
    
}

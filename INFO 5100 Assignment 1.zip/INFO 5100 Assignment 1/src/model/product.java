/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import javax.swing.ImageIcon;

/**
 *
 * @author sairammantravadi
 */
public class product {
    
    private String Brand;
    private String Model;
    private String Color;
    private String EngineNo;
    private String LicensePlates;
    private String OwnerName;
    private String EmailAddress;
    private String DriverLicense;
    private String Address;
    private String ServiceRecords;
    private int WarrantyYear;
    private int Year;
     private Double SocialSecurityNumber;
     private Double TelephoneNumber;
     private int Seats;
    private ImageIcon Photo;

    //Getters and Setters
    public String getBrand() {
        return Brand;
    }

    public void setBrand(String Brand) {
        this.Brand = Brand;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String Model) {
        this.Model = Model;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public int getYear() {
        return Year;
    }

    public void setYear(int Year) {
        this.Year = Year;
    }

    public String getEngineNo() {
        return EngineNo;
    }

    public void setEngineNo(String EngineNo) {
        this.EngineNo = EngineNo;
    }

    public int getSeats() {
        return Seats;
    }

    public void setSeats(int Seats) {
        this.Seats = Seats;
    }

    public String getLicensePlates() {
        return LicensePlates;
    }

    public void setLicensePlates(String LicensePlates) {
        this.LicensePlates = LicensePlates;
    }

    public String getOwnerName() {
        return OwnerName;
    }

    public void setOwnerName(String OwnerName) {
        this.OwnerName = OwnerName;
    }

    public Double getTelephoneNumber() {
        return TelephoneNumber;
    }

    public void setTelephoneNumber(Double TelephoneNumber) {
        this.TelephoneNumber = TelephoneNumber;
    }

    public String getEmailAddress() {
        return EmailAddress;
    }

    public void setEmailAddress(String EmailAddress) {
        this.EmailAddress = EmailAddress;
    }

    public String getDriverLicense() {
        return DriverLicense;
    }

    public void setDriverLicense(String DriverLicense) {
        this.DriverLicense = DriverLicense;
    }

    public Double getSocialSecurityNumber() {
        return SocialSecurityNumber;
    }

    public void setSocialSecurityNumber(Double SocialSecurityNumber) {
        this.SocialSecurityNumber = SocialSecurityNumber;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getServiceRecords() {
        return ServiceRecords;
    }

    public void setServiceRecords(String ServiceRecords) {
        this.ServiceRecords = ServiceRecords;
    }

    public int getWarrantyYear() {
        return WarrantyYear;
    }

    public void setWarrantyYear(int WarrantyYear) {
        this.WarrantyYear = WarrantyYear;
    }

    public ImageIcon getPhoto() {
        return Photo;
    }

    public void setPhoto(ImageIcon Photo) {
        this.Photo = Photo;
    }
       
    @Override
    public String toString(){
        
        return ServiceRecords;
        
    }
}

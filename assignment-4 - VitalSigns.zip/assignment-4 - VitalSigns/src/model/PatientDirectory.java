/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author sairammantravadi
 */
public class PatientDirectory {
//declaration
    
    private ArrayList<Patient> patientDirectory;
    
//methods
    
     public PatientDirectory() {
        this.patientDirectory = new ArrayList<Patient>();
    }

    public Patient addnewPatient() {
        Patient newPatient = new Patient();
        patientDirectory.add(newPatient);
        return newPatient;
    }
    
//getters and setters

    public ArrayList<Patient> getPatientDirectory() {
        return patientDirectory;
    }

    public void setPatientDirectory(ArrayList<Patient> patientDirectory) {
        this.patientDirectory = patientDirectory;
    }
    
}

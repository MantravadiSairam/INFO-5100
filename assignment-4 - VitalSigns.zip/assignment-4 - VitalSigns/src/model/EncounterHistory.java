/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author sairammantravadi
 */
public class EncounterHistory {
//declaration
    private ArrayList<Encounter> encounterHistory;
    
//methods
        public EncounterHistory() {
        this.encounterHistory = new ArrayList<Encounter>();
    }

    public Encounter addnewEncounter(){
    Encounter encounter = new Encounter();
    encounterHistory.add(encounter);
    return encounter;
    }
 
//getters and setters

    public ArrayList<Encounter> getEncounterHistory() {
        return encounterHistory;
    }

    public void setEncounterHistory(ArrayList<Encounter> encounterHistory) {
        this.encounterHistory = encounterHistory;
    }
    
}

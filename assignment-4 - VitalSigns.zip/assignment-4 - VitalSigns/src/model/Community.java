/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author sairammantravadi
 */
public class Community {
    //declaration
    private ArrayList<House> houseList;
    String community;
    
    //methods
    public Community(){
    this.houseList = new ArrayList<House>(); 
    }
    
    public House addnewHouse(){
    House newHouse = new House();
    houseList.add(newHouse);
    return newHouse;
    }
    
    
    //getters and setters

    public ArrayList<House> getHouseList() {
        return houseList;
    }

    public void setHouseList(ArrayList<House> houseList) {
        this.houseList = houseList;
    }

    public String getCommunity() {
        return community;
    }

    public void setCommunity(String community) {
        this.community = community;
    }
    
    
}

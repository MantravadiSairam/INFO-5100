/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author sairammantravadi
 */
public class City {
     private ArrayList<Community> community;
    private String cityName;
    
    
//methods
    public City() {
        this.cityName = new String();
        this.community = new ArrayList<Community>();
    }

    public Community addnewCommunity() {
        Community newCommunity = new Community();
        this.community.add(newCommunity);
        return newCommunity;
    }
    
    
//getters and setters

    public ArrayList<Community> getCommunity() {
        return community;
    }

    public void setCommunity(ArrayList<Community> community) {
        this.community = community;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }
    
    
}


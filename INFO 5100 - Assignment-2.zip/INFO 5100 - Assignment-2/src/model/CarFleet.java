
package model;

import java.util.ArrayList;

/**
 *
 * @author sairammantravadi
 */
public class CarFleet {
    private ArrayList<Car> fleet;
    
    public CarFleet(){
        this.fleet = new ArrayList<Car>();    
    }
    
    public Car addnewCar(){
        Car newCar = new Car();
        fleet.add(newCar);
        return newCar;
    }

    
    
    
    public ArrayList<Car> getFleet() {
        return fleet;
    }

    public void setFleet(ArrayList<Car> fleet) {
        this.fleet = fleet;
    }
}
